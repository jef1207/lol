
  # Design Telegram Mini App UI

  This is a code bundle for Design Telegram Mini App UI. The original project is available at https://www.figma.com/design/FiP5wkizsFlC5ItxEi2wBj/Design-Telegram-Mini-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  